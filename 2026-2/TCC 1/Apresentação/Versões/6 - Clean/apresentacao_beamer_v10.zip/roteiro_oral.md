# Roteiro oral

Pedro Brassi Luccas · Projeto de TCC · UNIFAL-MG

**Duração planejada: 10 minutos**, incluindo pausas breves e troca de slides. Os tempos são metas de ensaio, não duração garantida da leitura. Fale com naturalidade, sem ler as referências. O conteúdo é uma proposta de pesquisa: use o futuro ao descrever os experimentos.

| Slide | Tempo | Acumulado |
|---|---:|---:|
| 1. Capa | 25 s | 0:25 |
| 2. Contextualização | 50 s | 1:15 |
| 3. Resultados na literatura | 50 s | 2:05 |
| 4. Vazamento e lacuna científica | 60 s | 3:05 |
| 5. Justificativa | 45 s | 3:50 |
| 6. Objetivos | 50 s | 4:40 |
| 7. Base e preparação | 60 s | 5:40 |
| 8. Modelos e experimentos | 70 s | 6:50 |
| 9. Avaliação e explicabilidade | 60 s | 7:50 |
| 10. Hipóteses e limitações | 55 s | 8:45 |
| 11. Cronograma | 30 s | 9:15 |
| 12. Considerações finais | 40 s | 9:55 |
| 13. Referências | 5 s | 10:00 |

## 1. Capa — 25 segundos

Bom dia, professora.

Meu nome é Pedro Brassi Luccas, sou estudante de Ciência da Computação, e hoje vou apresentar minha proposta de Trabalho de Conclusão de Curso.

O projeto busca investigar o uso de Inteligência Artificial na classificação de tumores cerebrais a partir de imagens de ressonância magnética.

Mais especificamente, pretendo analisar não apenas o desempenho dos modelos, mas também a confiabilidade dos resultados obtidos.

## 2. Contextualização — 50 segundos

A ressonância magnética é um dos exames utilizados na investigação de tumores cerebrais, pois permite visualizar detalhadamente as estruturas do cérebro.

Entretanto, a interpretação dessas imagens exige conhecimento especializado e pode envolver a análise de uma grande quantidade de informações.

Nesse contexto, técnicas de Inteligência Artificial vêm sendo estudadas como ferramentas de apoio à análise de imagens médicas.

Essas técnicas conseguem aprender padrões visuais a partir de exemplos e utilizá-los para realizar classificações.

É justamente nessa aplicação que meu projeto está inserido.

## 3. Resultados na literatura — 50 segundos

Na literatura, encontramos trabalhos que apresentam resultados bastante elevados na classificação de tumores cerebrais utilizando Inteligência Artificial.

Por exemplo, Disci e colaboradores, em 2025, reportaram 98,73% de acurácia ponderada.

Rasa e colaboradores, em 2024, alcançaram 99,96% utilizando validação cruzada em conjuntos menores.

E Prayogo e colaboradores, em 2025, apresentaram 98,75% de acurácia.

Embora sejam resultados expressivos, esses estudos possuem metodologias diferentes, e uma acurácia elevada não garante, por si só, que o modelo terá o mesmo desempenho em imagens novas.

Isso nos leva a uma questão importante: será que a forma como organizamos os dados pode influenciar esses resultados?

## 4. Vazamento de dados e lacuna científica — 60 segundos

Uma possível explicação para resultados excessivamente elevados é o vazamento de dados.

Isso ocorre, por exemplo, quando imagens iguais ou relacionadas aparecem tanto no treinamento quanto no teste. É como aplicar uma prova com as mesmas questões da lista de exercícios: a nota sobe, mas não mede o aprendizado.

Yagis e colaboradores, em 2021, demonstraram que uma divisão inadequada de imagens de ressonância em fatias pode inflar artificialmente a acurácia em até 55 pontos percentuais em bases neurológicas de Alzheimer e Parkinson.

Já Fateh e colaboradores, em 2026, utilizaram uma base derivada do mesmo conjunto público que pretendo estudar e removeram duplicatas exatas e quase-duplicatas antes da divisão dos dados.

Com base no levantamento preliminar, a lacuna que investigo é a necessidade de avaliar conjuntamente o efeito das duplicatas e o equilíbrio entre desempenho e custo computacional dos modelos.

## 5. Justificativa — 45 segundos

Mas por que avaliar a confiabilidade dos resultados? A justificativa tem três dimensões.

Do ponto de vista teórico, a pesquisa investiga como a qualidade dos dados influencia a avaliação dos modelos.

Do ponto de vista social, busca contribuir para pesquisas mais confiáveis em apoio ao diagnóstico por imagem.

E, do ponto de vista tecnológico, pretende desenvolver um processo reprodutível de preparação dos dados, treinamento e avaliação.

O foco, portanto, é a confiabilidade do método computacional, e não uma ferramenta de uso clínico.

## 6. Objetivos da pesquisa — 50 segundos

Para investigar essa lacuna, o objetivo geral da minha pesquisa é desenvolver e avaliar modelos de Inteligência Artificial para classificar imagens de ressonância magnética cerebral, analisando não apenas seus acertos, mas também sua eficiência e a confiabilidade da avaliação.

O trabalho terá quatro etapas: auditar a base, treinar os modelos, comparar seus resultados e investigar os erros e as regiões que influenciaram as decisões.

## 7. Base de dados e preparação — 60 segundos

Para desenvolver o projeto, utilizarei uma base pública disponibilizada no Kaggle, chamada Brain Tumor MRI Dataset.

Ela contém imagens de ressonância magnética em quatro categorias: glioma, que se origina nas células da glia; meningioma, nas meninges; tumor hipofisário, na hipófise; e ausência de tumor, que funciona como grupo de comparação.

Antes do treinamento, será feita uma auditoria. Cada imagem recebe uma espécie de impressão digital, chamada hash, que permite encontrar cópias exatas e imagens quase idênticas.

Após a auditoria e o agrupamento, os dados serão separados em três conjuntos: 70% para treinamento, 15% para validação e 15% para teste.

Essa separação será feita buscando evitar que imagens duplicadas identificadas apareçam em conjuntos diferentes, tornando a avaliação mais confiável.

Depois, as imagens passarão por um pré-processamento, incluindo ajustes de tamanho e normalização, para que possam ser utilizadas pelos modelos. O aumento de dados ficará restrito ao treinamento.

## 8. Modelos e experimentos — 70 segundos

Depois da preparação dos dados, serão utilizados três modelos de Inteligência Artificial: ResNet50, EfficientNet-B0 e MobileNetV3.

Esses modelos já aprenderam a reconhecer formas e texturas em milhões de imagens comuns. Pela transferência de aprendizado, esse conhecimento é aproveitado e especializado para ressonâncias, assim como um profissional já formado faz uma especialização em vez de começar do zero.

As três arquiteturas foram escolhidas porque apresentam características diferentes. A ResNet50 utiliza uma estrutura profunda, a EfficientNet busca eficiência na relação entre desempenho e recursos, e a MobileNet foi projetada para aplicações com recursos computacionais mais limitados.

Além disso, utilizarei uma rede neural simples como referência de comparação.

Os experimentos serão realizados com e sem deduplicação, permitindo investigar tanto a influência da qualidade dos dados quanto as diferenças entre os modelos.

O efeito da deduplicação será medido comparando E1 com E3 e E2 com E5. As três arquiteturas serão comparadas na base deduplicada, nos experimentos E4, E5 e E6.

## 9. Avaliação dos modelos e explicabilidade — 60 segundos

Após o treinamento, os modelos serão avaliados considerando três aspectos principais.

O primeiro é o desempenho na classificação. Além da acurácia, utilizarei métricas que permitem analisar se o modelo apresenta bons resultados em todas as quatro categorias e identificar quais tipos de erro são mais frequentes.

O segundo aspecto é a eficiência computacional. Vou comparar o tamanho dos modelos, a quantidade de parâmetros e o tempo necessário para classificar uma imagem.

Por fim, pretendo utilizar uma técnica chamada Grad-CAM, que produz mapas visuais destacando regiões da imagem que contribuíram para a decisão da rede neural.

Com isso, será possível investigar se o modelo está utilizando regiões aparentemente relevantes ou se está se apoiando em características indesejadas.

Dessa forma, a comparação não será baseada somente na quantidade de acertos, mas também na eficiência e no comportamento das decisões.

## 10. Hipóteses e limitações — 55 segundos

O trabalho parte de duas hipóteses. A primeira é que remover imagens repetidas altera as métricas de classificação. A segunda é que os modelos apresentam diferenças de desempenho e custo computacional.

Além disso, haverá uma análise exploratória com o Grad-CAM, para investigar os erros e as regiões que influenciam as classificações.

Entretanto, a pesquisa apresenta algumas limitações.

A principal delas é que a base não disponibiliza identificadores dos pacientes, o que impede garantir uma separação completamente independente por paciente.

Além disso, os resultados podem variar em outras bases, e o estudo não valida o uso dos modelos no diagnóstico médico.

Portanto, a contribuição esperada é uma análise mais criteriosa e reprodutível da classificação de tumores cerebrais por Inteligência Artificial, que poderá servir de referência para estudos futuros.

## 11. Cronograma da pesquisa — 30 segundos

O cronograma da pesquisa está organizado inicialmente em seis meses, com ajustes a serem realizados junto ao orientador.

Até o momento, a definição do tema, do problema e a documentação inicial da base estão concluídas. A revisão bibliográfica e a redação estão parcialmente desenvolvidas.

As próximas etapas incluem a auditoria dos dados, o pré-processamento, o treinamento dos modelos e a avaliação dos resultados.

Por fim, serão realizadas as análises de explicabilidade, a revisão e a apresentação do trabalho.

## 12. Considerações finais — 40 segundos

Para concluir, meu projeto parte da ideia de que uma acurácia elevada não é suficiente para garantir a confiabilidade de um modelo de Inteligência Artificial.

Por isso, pretendo investigar a qualidade dos dados, comparar diferentes arquiteturas e analisar seus resultados de maneira mais criteriosa.

Espero que essa pesquisa contribua para uma compreensão mais consistente das possibilidades e limitações da Inteligência Artificial na classificação de imagens médicas.

Muito obrigado pela atenção. Fico à disposição para perguntas.

## 13. Referências bibliográficas — 5 segundos

Estas são as principais referências científicas que fundamentam a proposta.

## Apoio para perguntas — fora dos dez minutos

**O que é Macro F1?** É a média dos F1-Scores das quatro classes, atribuindo o mesmo peso a cada uma. O F1 combina precisão e sensibilidade. Ele ajuda a evitar que uma classe numerosa domine sozinha a avaliação.

**O Grad-CAM localiza o tumor?** Ele destaca regiões associadas à pontuação de uma classe. Não produz uma segmentação validada da lesão e não comprova correção clínica. Aqui será exploratório, aplicado ao modelo selecionado.

**Remover duplicatas resolve o vazamento?** Reduz uma fonte conhecida de contaminação, mas não garante independência por paciente. Os identificadores necessários não estão disponíveis, e imagens semelhantes podem representar cortes diferentes.

**O que significa “sem deduplicação” nos experimentos?** É a condição de referência planejada para investigar a influência das repetições. Será preciso documentar a composição e os denominadores de cada partição e preservar um protocolo comparável. Diferenças nas métricas devem ser interpretadas junto com mudanças na composição dos dados.

**Qual é a importância se não será uma ferramenta clínica?** A pesquisa avalia a confiabilidade dos métodos computacionais. Compreender desempenho, erros e limitações é necessário antes de qualquer futura validação clínica.

**Por que não usar apenas o maior percentual da literatura?** Porque tarefas, conjuntos e protocolos variam. O 99,96% de Rasa corresponde aos conjuntos menores com validação cruzada. O próprio artigo relata 96,34% a 98,20% nos conjuntos maiores.

**O que Yagis demonstrou?** Em bases de Alzheimer e Parkinson, mostrou inflação das métricas quando fatias relacionadas ficaram em treino e teste. Não estudou os tumores deste projeto nem demonstrou que os três trabalhos do slide 3 tenham vazamento.

**Diagnóstico precoce aumenta a sobrevida em tumores cerebrais?** Não afirme isso como fato. Uma revisão Cochrane (Grant et al., 2020) não encontrou estudos que avaliassem o efeito de reduzir o tempo de diagnóstico desses tumores. Por isso o slide fala em “diagnóstico oportuno” e em benefício indireto e futuro.

**E as hipóteses do pré-projeto?** O pré-projeto detalha quatro hipóteses (H1 a H4), incluindo a expectativa de que a EfficientNet-B0 tenha o melhor equilíbrio e de que o aumento de dados reduza o sobreajuste. O slide apresenta a versão resumida.

**Como a auditoria funciona?** O SHA-256 gera um código único por arquivo: arquivos idênticos têm o mesmo código. O pHash ou dHash gera um código pela aparência da imagem, e a distância de Hamming mede quão parecidos são dois códigos. Imagens parecidas não são excluídas automaticamente, porque podem ser cortes diferentes do mesmo exame; elas são agrupadas e inspecionadas por amostragem.

**Por que não aparecem AUC-ROC e especificidade?** Elas estão no pré-projeto e serão calculadas. O slide mostra as métricas mais fáceis de interpretar.

**A lacuna é inédita com certeza?** Ela corresponde ao levantamento preliminar do pré-projeto. A revisão será ampliada durante o TCC, portanto não se deve afirmar ausência universal de estudos semelhantes.

## Fontes para consulta

- Disci et al. (2025): https://doi.org/10.3390/cancers17010121
- Rasa et al. (2024): https://doi.org/10.1177/20552076241286140
- Prayogo, Hamid e Nambo (2025): https://doi.org/10.1109/ACCESS.2025.3584376
- Yagis et al. (2021): https://doi.org/10.1038/s41598-021-01681-w
- Fateh et al. (2026): https://doi.org/10.1038/s41597-026-06753-y
- Nickparvar (2021): https://www.kaggle.com/datasets/masoudnickparvar/brain-tumor-mri-dataset
- He et al. (2016): https://doi.org/10.1109/CVPR.2016.90
- Tan e Le (2019): https://proceedings.mlr.press/v97/tan19a.html
- Howard et al. (2019): https://doi.org/10.1109/ICCV.2019.00140
- Selvaraju et al. (2017): https://doi.org/10.1109/ICCV.2017.74
- Grant et al. (2020), Cochrane CD013564: https://doi.org/10.1002/14651858.CD013564.pub2
