# Apresentação de TCC em LaTeX Beamer

## Arquivos

- `apresentacao.tex`: fonte editável, com exatamente 13 slides e referências incorporadas. Não depende de BibTeX nem de tema externo; usa apenas `tikz` e `tcolorbox`, presentes no TeX Live, no MiKTeX e no Overleaf.
- `apresentacao.pdf`: versão para apresentação.
- `assets/`: seis imagens originais do dataset, necessárias à compilação.
- `roteiro_oral.md`: roteiro editável com falas, tempos e apoio para perguntas.
- `roteiro_oral.pdf`: versão de leitura e impressão.

## Edição e compilação

Mantenha `apresentacao.tex` e `assets/` na mesma pasta. No Overleaf, envie esses itens, selecione `apresentacao.tex` como documento principal e compile com pdfLaTeX. Localmente, com TeX Live ou MiKTeX:

```text
pdflatex apresentacao.tex
pdflatex apresentacao.tex
```

Também é possível compilar com XeLaTeX ou LuaLaTeX. O PDF entregue foi produzido com pdfLaTeX. O roteiro é separado e não acrescenta páginas ao PDF dos slides. Para mudanças no roteiro, edite o Markdown; o PDF é uma versão de leitura.

## Versão 2: revisão visual

- Identidade visual única: rótulo de seção acima de cada título (01 Contexto a 05 Perspectivas) e barra de progresso de 13 segmentos no rodapé.
- Capa com painel lateral que mostra as quatro classes da base. Encerramento em fundo escuro, com a mensagem principal em destaque.
- Slide 3: os três percentuais em cartões; o intervalo de Rasa nos conjuntos maiores (96,34–98,20%) aparece no próprio slide.
- Slide 4: esquema de vazamento com setas (treino × teste) e lacuna em destaque.
- Slide 7: fluxo de preparação em diagrama e barra proporcional 70/15/15.
- Slide 8: matriz de experimentos (modelos × com/sem deduplicação), indicando as duas comparações planejadas. Cada célula mostra o número do experimento, conforme as páginas 6 e 7 do pré-projeto: E1 e E2 (CNN e EfficientNet-B0 sem deduplicação), E3 (CNN deduplicada), E4, E5 e E6 (ResNet50, EfficientNet-B0 e MobileNetV3 deduplicadas).
- Slides 9 e 10: cartões por tema; slide 11 com marcadores C/P e linhas alternadas, mantendo as células vazias.
- Correções: os slides 4, 7 e 8 não sobrepõem mais as notas ao rodapé; o título do encerramento (slide 12) deixou de ser menor que os demais; o texto passou a ser alinhado à esquerda, sem espaços irregulares.

**Ajustes para banca de outra área (versão 4):** o slide 6 traz a pergunta de pesquisa do pré-projeto; o slide 7 indica a origem de cada tipo de tumor e explica a auditoria por *hash*; o slide 10 apresenta as hipóteses H1, H2 e H4 do pré-projeto (H3, sobre aumento de dados, fica no apoio para perguntas); o roteiro ganhou analogias para vazamento e transferência de aprendizado.

**Slide 3:** descrições simplificadas dos estudos e nota de rodapé reduzida a um aviso de não comparabilidade; os DOIs ficam no slide de referências.

**Slide 5 (Justificativa)**, acrescentado entre a lacuna e os objetivos, apresenta as dimensões teórica, social e tecnológica. A dimensão social fala em “diagnóstico oportuno” e em benefício indireto futuro, sem afirmar ganho de sobrevida: a revisão Cochrane CD013564 (Grant et al., 2020, https://doi.org/10.1002/14651858.CD013564.pub2) não encontrou estudos sobre o efeito de reduzir o tempo de diagnóstico de tumores cerebrais. O roteiro recebeu a fala desse slide, e os tempos foram redistribuídos para manter os 10 minutos. Os slides seguintes avançaram uma posição.

## Fidelidade ao conteúdo disponível

A estrutura original de 12 slides seguia a solicitação anterior e o conteúdo aprovado enviado nos dois textos colados, junto da conclusão recuperada na conversa. O título, a autoria, a orientação, a base e os sete experimentos também foram conferidos no PDF `Pre-Projeto_TCC_V1(1).pdf`.

Os ajustes de precisão mantêm o escopo aprovado: o percentual de Rasa é contextualizado como resultado em conjuntos menores, Macro F1 é explicado por precisão e sensibilidade (a AUC-ROC saiu do slide 9), e a ordem da preparação segue a correção metodológica já aprovada. O slide 9 explica Grad-CAM de forma conceitual, sem usar um mapa de outra imagem ou simular um resultado ainda não produzido. As falas aprovadas foram preservadas, com esses esclarecimentos pontuais e redistribuição dos tempos para aproximadamente dez minutos.

O slide 11 reproduz a tabela **visível** da página 8 do PDF: seis meses, treze atividades, C em “Tema e problema” e “Base e documentação”, P em “Revisão bibliográfica” e “Redação”, todos na coluna do mês 1. As demais células ficam vazias. A extração textual do PDF contém versões sobrepostas do cronograma, inclusive uma antiga com dez meses; a página renderizada confirma a versão de seis meses solicitada.

## Referências e precisão dos resultados

Consulta às fontes em 5 de novembro de 2026. Os três percentuais foram confirmados em fontes primárias:

| Estudo | Resultado e condição | Fonte |
|---|---|---|
| Disci, Gurcan e Soylu (2025) | 98,73% de acurácia ponderada para Xception | [Cancers](https://www.mdpi.com/2072-6694/17/1/121) |
| Rasa et al. (2024) | 99,96% com validação cruzada em conjuntos menores. Nos maiores, o resumo relata 96,34% a 98,20%. O destaque não é um resultado diretamente comparável ao mesmo conjunto de quatro classes dos outros artigos. | [Digital Health](https://journals.sagepub.com/doi/10.1177/20552076241286140) |
| Prayogo, Hamid e Nambo (2025) | 98,75% de acurácia para a combinação ResNet50V2 + MobileNetV2 + DenseNet121 | [IEEE Xplore](https://ieeexplore.ieee.org/document/11059942/) |

Yagis et al. investigaram vazamento por divisão em fatias em bases de Alzheimer e Parkinson. Por decisão do autor, o slide 4 omite o nome das doenças; a fala do roteiro mantém a menção para não atribuir o resultado a tumores cerebrais. O slide não acusa os três estudos de classificação de terem vazamento: [Scientific Reports](https://www.nature.com/articles/s41598-021-01681-w).

Fateh et al. documentam a remoção de duplicatas e quase duplicatas antes da divisão no desenvolvimento do BRISC e reconhecem limitações dos identificadores da coleção original: [Scientific Data](https://www.nature.com/articles/s41597-026-06753-y). BRISC é referência metodológica, não a base escolhida para os experimentos deste TCC.

Os registros originais das arquiteturas e da explicabilidade foram conferidos: [ResNet](https://openaccess.thecvf.com/content_cvpr_2016/html/He_Deep_Residual_Learning_CVPR_2016_paper.html), [EfficientNet](https://proceedings.mlr.press/v97/tan19a.html), [MobileNetV3](https://openaccess.thecvf.com/content_ICCV_2019/html/Howard_Searching_for_MobileNetV3_ICCV_2019_paper.html) e [Grad-CAM](https://openaccess.thecvf.com/content_iccv_2017/html/Selvaraju_Grad-CAM_Visual_Explanations_ICCV_2017_paper.html).

## Procedência das imagens

As imagens foram copiadas sem alteração do diretório autorizado pelo usuário:

`C:\Users\pedro\Desktop\Faculdade\2026-2\TCC 1\Brain Tumor MRI Dataset`

| Arquivo entregue | Arquivo de origem | Slide |
|---|---|---|
| `assets/meningioma-contexto.jpg` | `Training/meningioma/Tr-me_10.jpg` | 2 |
| `assets/exemplo-vazamento.jpg` | `Training/glioma/Tr-gl_10.jpg` | 4, repetida intencionalmente no esquema |
| `assets/glioma.jpg` | `Training/glioma/Tr-gl_1.jpg` | 1 e 7 |
| `assets/meningioma.jpg` | `Training/meningioma/Tr-me_1.jpg` | 1 e 7 |
| `assets/hipofisario.jpg` | `Training/pituitary/Tr-pi_1.jpg` | 1 e 7 |
| `assets/sem-tumor.jpg` | `Training/notumor/Tr-no_1.jpg` | 1 e 7 |

Fonte da coleção: Nickparvar, Masoud (2021), [Brain Tumor MRI Dataset](https://www.kaggle.com/datasets/masoudnickparvar/brain-tumor-mri-dataset). Os rótulos são os da base e não foram validados clinicamente nesta preparação. As imagens são exibidas sobre fundo preto, sem recorte nem distorção. Não foram acrescentadas setas, contornos de lesões ou mapas sintéticos de Grad-CAM. As imagens são exemplos da coleção, não resultados do projeto. A seleção ilustrativa não estabelece o conjunto de avaliação dos experimentos futuros.

## Ensaio

O roteiro distribui 600 segundos pelos 13 slides. Faça um ensaio cronometrado para adequar o ritmo e as pausas. O material de apoio para perguntas e as fontes de consulta ficam fora desse tempo.
